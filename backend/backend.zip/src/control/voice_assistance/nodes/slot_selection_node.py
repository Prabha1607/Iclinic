import json
from datetime import time, date
from src.control.voice_assistance.prompts.slot_selection_node_prompt import (
    LLM_DATE_SYSTEM,
    LLM_ALTERNATE_DATE_SYSTEM,
    LLM_CONFIRM_SYSTEM,
    LLM_PERIOD_SYSTEM,
    LLM_SLOT_SYSTEM,
    LLM_ALTERNATE_SLOT_SYSTEM,
    NO_SLOTS_RESPONSE,
)
from src.data.clients.postgres_client import AsyncSessionLocal
from src.data.repositories.generic_crud import bulk_get_instance
from src.data.models.postgres.available_slot import AvailableSlot
from src.data.models.postgres.appointment import Appointment
from src.data.models.postgres.ENUM import SlotStatus
from src.control.voice_assistance.models import get_llama1
from src.control.voice_assistance.utils import clear_markdown, update_state

MORNING_START   = time(6, 0)
MORNING_END     = time(12, 0)
AFTERNOON_START = time(12, 0)
AFTERNOON_END   = time(17, 0)
EVENING_START   = time(17, 0)
EVENING_END     = time(21, 0)


def classify_period(t: time) -> str:
    if MORNING_START <= t < MORNING_END:
        return "morning"
    elif AFTERNOON_START <= t < AFTERNOON_END:
        return "afternoon"
    elif EVENING_START <= t < EVENING_END:
        return "evening"
    return "night"


def fmt_time(t: time) -> str:
    return t.strftime("%I:%M %p").lstrip("0")


def fmt_date(d: date) -> str:
    return d.strftime("%A, %b %d %Y")


async def fetch_all_slots(doctor_id: int) -> list[dict]:
    try:
        async with AsyncSessionLocal() as db:
            today = date.today()

            all_slots = await bulk_get_instance(AvailableSlot, db, provider_id=doctor_id, is_active=True)

            future_available = [
                s for s in all_slots
                if s.availability_date >= today and s.status == SlotStatus.AVAILABLE
            ]

            all_appointments = await bulk_get_instance(Appointment, db, provider_id=doctor_id, is_active=True)

            booked_slot_ids = {
                a.availability_slot_id for a in all_appointments
                if str(a.status.value).upper() in ("SCHEDULED", "CONFIRMED")
            }

            return [
                {
                    "id":           s.id,
                    "date":         s.availability_date,
                    "start_time":   s.start_time,
                    "end_time":     s.end_time,
                    "period":       classify_period(s.start_time),
                    "display":      f"{fmt_time(s.start_time)} → {fmt_time(s.end_time)}",
                    "full_display": f"{fmt_time(s.start_time)} → {fmt_time(s.end_time)} on {fmt_date(s.availability_date)}",
                }
                for s in future_available
                if s.id not in booked_slot_ids
            ]
    except Exception as e:
        print("[fetch_all_slots error]:", e)
        return []


def slots_for_date(all_slots: list[dict], target: date) -> list[dict]:
    return [s for s in all_slots if s["date"] == target]


def periods_on_date(slots: list[dict]) -> dict[str, list]:
    periods: dict[str, list] = {}
    for s in slots:
        periods.setdefault(s["period"], []).append(s)
    return periods


async def llm_extract(system: str, human: str) -> dict:
    try:
        llm = get_llama1()
        response = await llm.ainvoke([("system", system), ("human", human)])
        raw = response.content.strip()
        try:
            return json.loads(clear_markdown(raw))
        except Exception as e:
            print("[llm_extract parse error]:", e, "| raw:", raw)
            return {}
    except Exception as e:
        print("[llm_extract error]:", e)
        return {}


def _parse_date(chosen_date_str: str | None) -> date | None:
    try:
        return date.fromisoformat(chosen_date_str) if chosen_date_str else None
    except Exception:
        return None


def _build_date_options(available_dates: list[date]) -> str:
    return "\n".join(f"{fmt_date(d)} -> {d.isoformat()}" for d in available_dates)


def _build_slot_context(slots: list[dict], use_full_display: bool = False) -> str:
    display_key = "full_display" if use_full_display else "display"
    return "\n".join(
        f"slot_id={s['id']} start_time={s['start_time']} end_time={s['end_time']} display={s[display_key]}"
        for s in slots
    )

def _nearest_alt_dates(chosen_date: date, available_dates: list[date]) -> list[date]:
    before = sorted([d for d in available_dates if d < chosen_date], reverse=True)
    after  = sorted([d for d in available_dates if d > chosen_date])

    alts = []
    if before:
        alts.append(before[0])
    alts.extend(after[:2])

    if len(alts) < 3:
        if not before and len(after) >= 3:
            alts = after[:3]
        elif not after and len(before) >= 3:
            alts = sorted(before[:3])

    return sorted(set(alts))[:3]


async def _proceed_to_period(state: dict, doctor_name: str, chosen_date: date, date_slots: list) -> dict:
    periods           = periods_on_date(date_slots)
    available_periods = list(periods.keys())

    if len(available_periods) == 1:
        chosen_period = available_periods[0]
        period_slots  = periods[chosen_period]
        slot_lines    = "\n".join(f"  - {s['display']}" for s in period_slots)
        return update_state(
            state,
            slot_stage="ask_slot",
            slot_chosen_date=chosen_date,
            slot_chosen_period=chosen_period,
            slot_available_list=period_slots,
            speech_ai_text=(
                f"{doctor_name} only has {chosen_period} availability on {fmt_date(chosen_date)}. "
                f"Here are the open slots:\n{slot_lines}\n"
                "Which time works best for you?"
            ),
        )

    period_lines = "\n".join(f"  - {p}" for p in available_periods)
    return update_state(
        state,
        slot_stage="ask_period",
        slot_chosen_date=chosen_date,
        speech_ai_text=(
            f"{doctor_name} is available in the {', '.join(available_periods)} "
            f"on {fmt_date(chosen_date)}.\n{period_lines}\n"
            "Which part of the day works better for you?"
        ),
    )


async def _handle_ask_date(
    state: dict, user_text: str, doctor_name: str, all_slots: list[dict], available_dates: list[date]
) -> dict:
    today  = date.today()
    parsed = await llm_extract(
        system=LLM_DATE_SYSTEM.format(today=today.isoformat()),
        human=user_text,
    )

    chosen_date = _parse_date(parsed.get("date"))

    if chosen_date is None:
        return update_state(
            state,
            slot_stage="ask_date",
            speech_ai_text=(
                "Sorry, I didn't quite catch that. "
                "Did you have a particular date in mind? "
                "You can say something like 'March 8' or 'next Monday'."
            ),
        )

    date_slots = slots_for_date(all_slots, chosen_date)

    if date_slots:
        return update_state(
            state,
            slot_stage="confirm_date",
            slot_chosen_date=chosen_date,
            speech_ai_text=(
                f"Got it — {fmt_date(chosen_date)}. "
                f"Just to confirm, you'd like to book with {doctor_name} on that date. Is that correct?"
            ),
        )

    alts = _nearest_alt_dates(chosen_date, available_dates)

    if not alts:
        return update_state(
            state,
            slot_stage="ask_date",
            speech_ai_text=f"I'm sorry, {doctor_name} has no upcoming availability right now.",
        )

    alt_lines = "\n".join(f"  - {fmt_date(d)}" for d in alts)
    return update_state(
        state,
        slot_stage="ask_alternate_date",
        speech_ai_text=(
            f"Unfortunately {doctor_name} isn't available on {fmt_date(chosen_date)}. "
            f"The nearest available dates are:\n{alt_lines}\n"
            "Would any of those work for you?"
        ),
    )


async def _handle_confirm_date(
    state: dict, user_text: str, doctor_name: str, all_slots: list[dict], available_dates: list[date]
) -> dict:
    chosen_date: date = state.get("slot_chosen_date")

    parsed    = await llm_extract(system=LLM_CONFIRM_SYSTEM, human=user_text)
    confirmed = parsed.get("confirmed")

    if confirmed is True:
        date_slots = slots_for_date(all_slots, chosen_date)
        return await _proceed_to_period(state, doctor_name, chosen_date, date_slots)

    today  = date.today()
    parsed2 = await llm_extract(
        system=LLM_DATE_SYSTEM.format(today=today.isoformat()),
        human=user_text,
    )
    new_date = _parse_date(parsed2.get("date"))

    if new_date and new_date != chosen_date:
        date_slots = slots_for_date(all_slots, new_date)

        if date_slots:
            return update_state(
                state,
                slot_stage="confirm_date",
                slot_chosen_date=new_date,
                speech_ai_text=(
                    f"Got it — {fmt_date(new_date)}. "
                    f"Confirming with {doctor_name} on that date. Is that correct?"
                ),
            )

        alts = _nearest_alt_dates(new_date, available_dates)
        alt_lines = "\n".join(f"  - {fmt_date(d)}" for d in alts)
        return update_state(
            state,
            slot_stage="ask_alternate_date",
            speech_ai_text=(
                f"Unfortunately {doctor_name} isn't available on {fmt_date(new_date)}. "
                f"The nearest available dates are:\n{alt_lines}\n"
                "Would any of those work for you?"
            ),
        )

    return update_state(
        state,
        slot_stage="ask_date",
        slot_chosen_date=None,
        slot_chosen_period=None,
        slot_available_list=None,
        speech_ai_text=f"No problem! What date would you prefer with {doctor_name}?",
    )


async def _handle_ask_alternate_date(
    state: dict, user_text: str, doctor_name: str, all_slots: list[dict], available_dates: list[date]
) -> dict:
    today  = date.today()
    parsed = await llm_extract(
        system=LLM_ALTERNATE_DATE_SYSTEM.format(
            today=today.isoformat(),
            date_options=_build_date_options(available_dates),
        ),
        human=user_text,
    )

    chosen_date = _parse_date(parsed.get("date"))
    date_slots  = slots_for_date(all_slots, chosen_date) if chosen_date else []

    if not date_slots:
        date_lines = "\n".join(f"  - {fmt_date(d)}" for d in available_dates)
        return update_state(
            state,
            slot_stage="ask_alternate_date",
            speech_ai_text=(
                f"No problem. Here are all the dates {doctor_name} is available:\n"
                f"{date_lines}\n"
                "Which one would you like?"
            ),
        )

    return update_state(
        state,
        slot_stage="confirm_date",
        slot_chosen_date=chosen_date,
        speech_ai_text=(
            f"Got it — {fmt_date(chosen_date)}. "
            f"Just to confirm, you'd like to book with {doctor_name} on that date. Is that correct?"
        ),
    )


async def _handle_ask_period(
    state: dict, user_text: str, doctor_name: str, all_slots: list[dict]
) -> dict:
    chosen_date: date = state.get("slot_chosen_date")
    date_slots        = slots_for_date(all_slots, chosen_date)
    periods           = periods_on_date(date_slots)
    available_periods = list(periods.keys())

    parsed        = await llm_extract(
        system=LLM_PERIOD_SYSTEM.format(available_periods=available_periods),
        human=user_text,
    )
    chosen_period = (parsed.get("period") or "").lower()

    if chosen_period not in periods:
        period_lines = "\n".join(f"  - {p}" for p in available_periods)
        return update_state(
            state,
            slot_stage="ask_period",
            speech_ai_text=(
                f"Sorry, {doctor_name} isn't available "
                f"{'in the ' + chosen_period + ' ' if chosen_period else ''}"
                f"on {fmt_date(chosen_date)}. "
                f"Available periods are:\n{period_lines}\n"
                "Which would you prefer?"
            ),
        )

    period_slots = periods[chosen_period]
    slot_lines   = "\n".join(f"  - {s['display']}" for s in period_slots)
    return update_state(
        state,
        slot_stage="ask_slot",
        slot_chosen_period=chosen_period,
        slot_available_list=period_slots,
        speech_ai_text=(
            f"Here are the {chosen_period} slots available on {fmt_date(chosen_date)} "
            f"with {doctor_name}:\n{slot_lines}\n"
            "Which time works best for you?"
        ),
    )


async def _handle_ask_slot(
    state: dict, user_text: str, doctor_name: str, all_slots: list[dict]
) -> dict:
    period_slots: list = state.get("slot_available_list", [])
    chosen_date: date  = state.get("slot_chosen_date")

    parsed  = await llm_extract(
        system=LLM_SLOT_SYSTEM.format(slots_context=_build_slot_context(period_slots)),
        human=user_text,
    )
    slot_id = parsed.get("slot_id")

    if not slot_id:
        other_slots = [s for s in all_slots if s["date"] != chosen_date]

        if not other_slots:
            slot_lines = "\n".join(f"  - {s['display']}" for s in period_slots)
            return update_state(
                state,
                slot_stage="ask_slot",
                speech_ai_text=(
                    f"There are no other slots available for {doctor_name} right now. "
                    f"The available times on {fmt_date(chosen_date)} are:\n{slot_lines}\n"
                    "Would any of these work?"
                ),
            )

        next_dates     = sorted({s["date"] for s in other_slots})[:2]
        alt_date_slots = [s for s in all_slots if s["date"] in next_dates][:5]
        alt_lines      = "\n".join(f"  - {s['full_display']}" for s in alt_date_slots)
        return update_state(
            state,
            slot_stage="ask_alternate_slot",
            slot_available_list=alt_date_slots,
            speech_ai_text=(
                f"No problem! Here are some alternative slots for {doctor_name}:\n"
                f"{alt_lines}\n"
                "Would any of these work for you?"
            ),
        )

    matched = next((s for s in period_slots if s["id"] == int(slot_id)), period_slots[0])
    return update_state(
        state,
        slot_stage="ready_to_book",
        slot_selection_completed=True,
        slot_selected=matched,
    )


async def _handle_ask_alternate_slot(
    state: dict, user_text: str, doctor_name: str, all_slots: list[dict], available_dates: list[date]
) -> dict:
    period_slots: list = state.get("slot_available_list", [])

    parsed  = await llm_extract(
        system=LLM_ALTERNATE_SLOT_SYSTEM.format(
            slots_context=_build_slot_context(period_slots, use_full_display=True)
        ),
        human=user_text,
    )
    slot_id = parsed.get("slot_id")

    if not slot_id:
        return update_state(
            state,
            slot_stage="ask_date",
            slot_chosen_date=None,
            slot_chosen_period=None,
            slot_available_list=None,
            speech_ai_text=f"No worries! Let's try again — what date works best for you with {doctor_name}?",
        )

    matched = next((s for s in period_slots if s["id"] == int(slot_id)), period_slots[0])
    return update_state(
        state,
        slot_stage="ready_to_book",
        slot_selection_completed=True,
        slot_selected=matched,
    )


async def slot_selection_node(state: dict) -> dict:
    print("[slot_selection_node] -----------------------------")

    if state.get("slot_booked_id"):
        return {**state, "slot_selection_completed": True}

    doctor_id:   int = state.get("doctor_confirmed_id")
    doctor_name: str = state.get("doctor_confirmed_name", "the doctor")
    user_text:   str = (state.get("speech_user_text") or "").strip()
    slot_stage:  str = state.get("slot_stage")

    try:
        all_slots = await fetch_all_slots(doctor_id)
    except Exception as e:
        print("[slot_selection_node] fetch_all_slots failed:", e)
        return update_state(
            state,
            slot_selection_completed=False,
            speech_ai_text="Sorry, I ran into an issue fetching available slots. Please try again.",
        )

    if not all_slots:
        return update_state(
            state,
            slot_selection_completed=False,
            speech_ai_text=NO_SLOTS_RESPONSE.format(doctor_name=doctor_name),
        )

    available_dates = sorted({s["date"] for s in all_slots})

    if slot_stage is None:
        return update_state(
            state,
            slot_stage="ask_date",
            slot_selection_completed=False,
            speech_ai_text=(
                f"Great! Now let's find a good time with {doctor_name}. "
                f"What date were you thinking?"
            ),
        )

    handler_map = {
        "ask_date":           lambda: _handle_ask_date(state, user_text, doctor_name, all_slots, available_dates),
        "confirm_date":       lambda: _handle_confirm_date(state, user_text, doctor_name, all_slots, available_dates),
        "ask_alternate_date": lambda: _handle_ask_alternate_date(state, user_text, doctor_name, all_slots, available_dates),
        "ask_period":         lambda: _handle_ask_period(state, user_text, doctor_name, all_slots),
        "ask_slot":           lambda: _handle_ask_slot(state, user_text, doctor_name, all_slots),
        "ask_alternate_slot": lambda: _handle_ask_alternate_slot(state, user_text, doctor_name, all_slots, available_dates),
    }

    handler = handler_map.get(slot_stage)
    if handler is None:
        return state

    try:
        return await handler()
    except Exception as e:
        print(f"[slot_selection_node] stage={slot_stage} error:", e)
        return update_state(
            state,
            speech_ai_text="Sorry, something went wrong. Could you please repeat that?",
        )
    

    